<?php $__env->startSection('body'); ?>

    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    

    
    <!-- end row -->

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title text-center font-weight-bolder">Detail Blog Info</h4>

                    <table  class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <tr>
                            <th>Blog Id</th>
                            <th><?php echo e($blog->id); ?></th>
                        </tr>
                        <tr>
                            <th>Blog Main Title</th>
                            <th><?php echo e($blog->main_title); ?></th>
                        </tr>
                        <tr>
                            <th>Blog Sub Title</th>
                            <th><?php echo e($blog->sub_title); ?></th>
                        </tr>
                        <tr>
                            <th>Blog Author</th>
                            <th><?php echo e($blog->author_id); ?></th>
                        </tr>
                        <tr>
                            <th>Blog Short Description</th>
                            <th><?php echo e($blog->short_description); ?></th>
                        </tr>
                        <tr>
                            <th>Blog Long Description</th>
                            <th><?php echo $blog->long_description; ?></th>
                        </tr>
                        <tr>
                            <th>Blog Image</th>
                            <th><img src="<?php echo e(asset($blog->image)); ?>" alt="" height="150" width="150"></th>
                        </tr>
                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PHP With Laravel_B3\Blog_laravel\blog\resources\views/admin/blog/detail.blade.php ENDPATH**/ ?>